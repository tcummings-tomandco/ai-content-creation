# Authority article engine — Claude Code skill bundle

A portable Claude Code skill that researches, drafts, and QA-checks authority-style articles optimised for citation by LLMs (Generative Engine Optimisation, GEO). Built originally for Tom & Co (a UK AI agency), but the skill is structured so the substantive editorial rules can be adapted to other brands and verticals with edits to a small number of files.

## What this bundle gives you

| File | Purpose | Adapt for a new project? |
|---|---|---|
| `.claude/skills/tomandco-article/SKILL.md` | The skill entry point. Defines the run order: load context → research → plan → draft → schema → QA → outputs → email. Reference this from any Claude Code session that should write articles. | Rename the skill folder. Update internal references. Otherwise reuse as-is. |
| `.claude/skills/tomandco-article/voice-guide.md` | The voice rules — Tom & Co specifics plus ~40 banned AI-tell words/phrases that the QA scan blocks on. The "no em dashes" and "no banned-word" rules are universal; the brand voice notes are Tom & Co's. | Rewrite the brand-voice section for your brand. Keep the universal AI-tell list. |
| `.claude/skills/tomandco-article/checklist.md` | The 10-element GEO QA gate. Grounded in the Princeton/KDD GEO research and 2025–2026 industry replications. PASS/FAIL criteria for every element. | Reuse as-is. The 10 elements are domain-agnostic. |
| `.claude/skills/tomandco-article/stat-sourcing.md` | Three-layer strategy for getting an honest, defensible primary-source statistic into every article. UK examples; framework is universal. | Reuse as-is for any market. Swap the UK source register for your market's primary sources. |
| `.claude/skills/tomandco-article/format-mapping.md` | Ten article-skeleton templates keyed by topic format (decision tree, comparison, definition + benchmark, sector report, listicle, framework, analysis, template, glossary). | Reuse as-is. The skeletons are domain-agnostic. |
| `scripts/voice_check.py` | Mechanical voice compliance scan — em dashes, banned words, paragraph length, H2 question form, "we"/"our" frequency, bold count. Splits paragraphs correctly across `<p>`, `<li>`, `<td>`, `<h*>`, `<aside>`. | Reuse as-is. Edit the `BANNED_WORDS` list if you want a different strictness profile. |
| `scripts/pick_next_topic.py` | Priority-ordered queue picker (P0 → P1 quick-wins → P1 → P2 → P3). Reads `data/roadmap.json`. | Reuse as-is. Replace the roadmap data file. |
| `scripts/publish_preview.py` | Copies an approved article's `preview.html` into `docs/previews/{slug}/index.html` for serving via GitHub Pages. Injects `noindex,nofollow` and a "Phase 1 preview" banner. | Reuse as-is. |
| `routines/run.md` | The routine prompt — paste into a fresh Claude Code session to invoke the skill end-to-end on the next queue item. | Reuse as-is. Edit recipient email and brand name. |
| `data/roadmap.template.json` | Schema for the topic queue. | Replace with your own topics, ideally exported from your editorial spreadsheet. |
| `data/stat_bank.template.json` | Empty stat bank. The engine appends an entry per Layer 2 original calculation. | Reuse as-is. |

## Installing in another project

1. **Copy the bundle** into your project root:
   ```
   project-root/
     .claude/skills/tomandco-article/
     scripts/
     routines/
     data/
   ```

2. **Rename the skill folder** to match your brand:
   ```bash
   mv .claude/skills/tomandco-article .claude/skills/{your-brand}-article
   ```
   Then update the `name:` field in the SKILL.md frontmatter to match.

3. **Replace data templates with your data:**
   ```bash
   cp data/roadmap.template.json data/roadmap.json
   cp data/stat_bank.template.json data/stat_bank.json
   ```
   Populate `roadmap.json` from your editorial spreadsheet — the picker expects rows with ID, Priority, Quick win, Cluster, Format, etc.

4. **Edit the voice guide** (`voice-guide.md`) to reflect your brand's voice. Sections to rewrite:
   - "Source: what {brand} actually sounds like" — list your real corpus and patterns.
   - "What changes for the GEO content engine" — how the brand voice shifts for authority articles vs marketing copy.
   Keep the "Hard rules" section (no em dashes, banned words, etc.) almost verbatim — it is brand-agnostic and represents the strongest known anti-AI-tell ruleset as of 2026.

5. **Edit `format-mapping.md`** to add or remove article skeletons your editorial roadmap calls for. The default 10 cover most authority-content patterns.

6. **Adjust source preferences** (`stat-sourcing.md` and `format-mapping.md`):
   - Swap UK regulators / sources for your market's primary sources.
   - Sterling pricing → your currency.
   - UK funding lines → your market's equivalents.

7. **Test the queue picker:**
   ```bash
   python3 scripts/pick_next_topic.py --list 8
   ```

8. **Test the voice check on an existing piece of your content** (it should flag issues — that's how you calibrate your starting point):
   ```bash
   python3 scripts/voice_check.py path/to/your-article.html
   ```

9. **Configure the email recipient** in `routines/run.md` (currently set to a Tom & Co address).

10. **Run an end-to-end dry-run** on one topic by pasting `routines/run.md` into a fresh Claude Code session.

## What is opinionated and what is not

**Opinionated and brand-specific (you must edit):**
- Voice samples and brand patterns in `voice-guide.md`
- The roadmap (your editorial topics)
- Currency, regulators, funding lines, primary-source preferences
- Author byline and LinkedIn URL
- Email recipient

**Opinionated but universal (reuse as-is):**
- The 10-element GEO checklist
- The 3-layer stat-sourcing strategy
- The ~40 banned AI-tell words and phrases (em dashes, "delve", "leverage", "robust", "comprehensive", etc.)
- The 10 article skeletons in `format-mapping.md`
- The voice-check rules around paragraph length, H2 question form, bold density, "we"/"our" frequency

**Phase 1 vs Phase 2:**
- Phase 1: engine writes outputs locally; human approves; manual publish.
- Phase 2: engine opens PRs against the website repo on approval. The current bundle is Phase 1 only — adapt the publish step to your CMS or static site when ready.

## Origin and methodology

The QA gate and voice rules are grounded in:

- Princeton/KDD GEO study (2024) and its 2025–2026 industry replications (Profound, ALMCorp, ConvertMate, SemRush, Ahrefs, Search Engine Land).
- The 10-element editorial template was developed for Tom & Co (April 2026) as the operational translation of the GEO research into a per-article checklist editors can enforce in review.
- The "no em dashes" rule and the banned-word list are derived from observed AI-tell patterns LLMs increasingly down-weight in 2026.

## Licence

This bundle is provided to Tom Cummings / Tom & Co for use in any project. No formal licence — treat as work-for-hire output unless agreed otherwise.

## Files

```
tomandco-skill-bundle/
├── README.md                                    (this file)
├── .claude/skills/tomandco-article/
│   ├── SKILL.md
│   ├── voice-guide.md
│   ├── checklist.md
│   ├── stat-sourcing.md
│   └── format-mapping.md
├── scripts/
│   ├── voice_check.py
│   ├── pick_next_topic.py
│   └── publish_preview.py
├── routines/
│   └── run.md
└── data/
    ├── roadmap.template.json
    └── stat_bank.template.json
```
